// Solicitar al usuario la cantidad de palabras que desea ingresar
let cantidad = parseInt(prompt("¿Cuántas palabras deseas ingresar?"), 10);

// Verificar que la cantidad sea un número válido
if (isNaN(cantidad) || cantidad <= 0) {
  console.log("Por favor, ingresa un número válido mayor que cero.");
} else {
  // Inicializar el arreglo para almacenar las palabras
  let palabras = [];

  // Solicitar al usuario que ingrese las palabras
  for (let i = 0; i < cantidad; i++) {
    let palabra = prompt(`Ingresa la palabra ${i + 1}:`);
    if (palabra) {
      palabras.push(palabra);
    } else {
      console.log("Entrada no válida. Intenta de nuevo.");
      i--; // Decrementar el contador para repetir la iteración
    }
  }

  const longitudes = palabras
    .filter(palabra => palabra.length > 2) 
    .map(palabra => palabra.length); 


  console.log("Longitudes de palabras con más de 2 caracteres:", longitudes);
}
